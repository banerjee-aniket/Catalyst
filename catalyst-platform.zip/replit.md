# Catalyst Platform: Development Guide

## Overview

Catalyst is a web application designed to support entrepreneurial activities within an educational context. It provides a platform for users to share and explore startup ideas, form teams, access resources, connect with mentors, and participate in entrepreneurship-related events.

Preferred communication style: Simple, everyday language.

## User Preferences

- Prefer clear, concise code with proper TypeScript typing
- Follow the existing project structure and patterns
- Use the shadcn/ui component library for UI elements
- Implement responsive designs that work well on both desktop and mobile
- Add comments for complex logic but keep them concise
- Prioritize a clean and intuitive user experience

## System Architecture

The application follows a modern web architecture with:

1. **Frontend**: React-based single-page application with TypeScript
2. **Backend**: Node.js Express server
3. **Database**: PostgreSQL database with Drizzle ORM
4. **Authentication**: Session-based authentication with Passport.js
5. **Styling**: Tailwind CSS with shadcn/ui components

The application uses a monorepo structure where both the client and server code reside in the same repository. The frontend and backend share type definitions and schema through the `shared` directory.

## Key Components

### Frontend

1. **Client Structure**:
   - `client/src/components`: UI components (both custom and shadcn/ui)
   - `client/src/hooks`: Custom React hooks for state management and logic
   - `client/src/lib`: Utility functions and API clients
   - `client/src/pages`: Page components mapped to routes

2. **UI Framework**:
   - Uses shadcn/ui components, which are built on Radix UI
   - Tailwind CSS for styling with a custom theme

3. **State Management**:
   - React Query for server state (data fetching, caching, updates)
   - React context for application state (auth, themes)

4. **Routing**:
   - Uses wouter for client-side routing

### Backend

1. **Server Structure**:
   - `server/index.ts`: Main entry point
   - `server/routes.ts`: API route definitions
   - `server/storage.ts`: Database abstraction layer
   - `server/vite.ts`: Development server setup

2. **API Implementation**:
   - RESTful API design
   - JSON response format
   - Organized around resources (users, ideas, teams, etc.)

3. **Authentication**:
   - Session-based with Passport.js
   - Uses bcrypt for password hashing

### Database

1. **Schema**:
   - Defined in `shared/schema.ts`
   - Uses Drizzle ORM for database operations
   - Schema includes users, skills, ideas, comments, teams, resources, events, mentors, and messages

2. **Migrations**:
   - Managed with Drizzle Kit

## Data Flow

1. **API Request Flow**:
   - Client makes request to the API endpoints (/api/*)
   - Express router handles the request and routes to appropriate handler
   - Handler performs business logic, often interacting with the database
   - Results are returned as JSON

2. **Authentication Flow**:
   - User logs in with username/password
   - Server verifies credentials and creates a session
   - Session is stored and session ID is sent to client as a cookie
   - Subsequent requests include the session cookie for authentication

3. **Data Fetching**:
   - React components use React Query hooks to fetch data
   - Query results are cached for performance
   - UI updates automatically when data changes

## External Dependencies

### Frontend Dependencies
- **React & React DOM**: Core UI library
- **@tanstack/react-query**: Data fetching and state management
- **wouter**: Lightweight routing
- **date-fns**: Date formatting utilities
- **Radix UI components**: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **clsx & tailwind-merge**: CSS class manipulation

### Backend Dependencies
- **express**: Web server framework
- **passport**: Authentication middleware
- **bcryptjs**: Password hashing
- **connect-pg-simple**: Session storage for PostgreSQL
- **drizzle-orm**: Database ORM
- **@neondatabase/serverless**: PostgreSQL client for serverless environments
- **zod**: Schema validation

## Deployment Strategy

The application is configured to deploy in a Replit environment with:

1. **Development Mode**:
   - Run with `npm run dev`
   - Uses Vite for frontend development with HMR
   - Server runs in development mode with auto-reloading

2. **Production Build**:
   - Build with `npm run build`
   - Frontend assets are compiled to `dist/public`
   - Server is bundled to `dist/index.js`
   - Run with `npm run start`

3. **Database**:
   - Uses PostgreSQL
   - Configuration via environment variables
   - Schema updates with Drizzle migrations

## Development Workflow

1. **Setup**:
   - Ensure PostgreSQL is running
   - Set the `DATABASE_URL` environment variable
   - Run `npm install` to install dependencies

2. **Development**:
   - Run `npm run dev` to start the development server
   - Frontend is available at the root path
   - API endpoints are available at `/api/*`

3. **Database Updates**:
   - Update schema in `shared/schema.ts`
   - Run `npm run db:push` to apply changes to the database

4. **Deployment**:
   - The `.replit` file configures the deployment settings
   - The application is built and run automatically on Replit