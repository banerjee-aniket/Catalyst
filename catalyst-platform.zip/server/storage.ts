import {
  User, InsertUser,
  Skill, InsertSkill,
  Idea, InsertIdea, IdeaWithDetails, IdeaWithUser,
  Comment, InsertComment, CommentWithUser,
  Team, InsertTeam, TeamWithMembers,
  InsertTeamMember,
  ResourceCategory, InsertResourceCategory,
  Resource, InsertResource,
  Event, InsertEvent,
  Mentor, InsertMentor,
  Message, InsertMessage,
  InsertIdeaTag,
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Skill methods
  getSkills(): Promise<Skill[]>;
  getSkillsByCategory(category: string): Promise<Skill[]>;
  createSkill(skill: InsertSkill): Promise<Skill>;
  getUserSkills(userId: number): Promise<Skill[]>;
  addUserSkill(userId: number, skillId: number): Promise<void>;
  removeUserSkill(userId: number, skillId: number): Promise<void>;
  
  // Idea methods
  getIdea(id: number): Promise<IdeaWithDetails | undefined>;
  getIdeas(limit?: number, featured?: boolean): Promise<IdeaWithUser[]>;
  getUserIdeas(userId: number): Promise<Idea[]>;
  createIdea(idea: InsertIdea): Promise<Idea>;
  updateIdea(id: number, idea: Partial<Idea>): Promise<Idea | undefined>;
  deleteIdea(id: number): Promise<boolean>;
  addIdeaTag(ideaTag: InsertIdeaTag): Promise<void>;
  getIdeaTags(ideaId: number): Promise<string[]>;
  likeIdea(id: number): Promise<Idea | undefined>;
  
  // Comment methods
  getComments(ideaId: number): Promise<CommentWithUser[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  
  // Team methods
  getTeam(id: number): Promise<TeamWithMembers | undefined>;
  getTeams(): Promise<Team[]>;
  getUserTeams(userId: number): Promise<Team[]>;
  createTeam(team: InsertTeam): Promise<Team>;
  addTeamMember(teamMember: InsertTeamMember): Promise<void>;
  removeTeamMember(teamId: number, userId: number): Promise<boolean>;
  
  // Resource methods
  getResourceCategories(): Promise<ResourceCategory[]>;
  createResourceCategory(category: InsertResourceCategory): Promise<ResourceCategory>;
  getResources(categoryId?: number): Promise<Resource[]>;
  createResource(resource: InsertResource): Promise<Resource>;
  
  // Event methods
  getEvents(): Promise<Event[]>;
  createEvent(event: InsertEvent): Promise<Event>;
  
  // Mentor methods
  getMentors(featured?: boolean): Promise<Mentor[]>;
  createMentor(mentor: InsertMentor): Promise<Mentor>;
  
  // Message methods
  getUserMessages(userId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: number): Promise<Message | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private skills: Map<number, Skill>;
  private userSkills: Map<string, boolean>; // userId-skillId
  private ideas: Map<number, Idea>;
  private ideaTags: Map<string, string>; // ideaId-tag
  private comments: Map<number, Comment>;
  private teams: Map<number, Team>;
  private teamMembers: Map<string, { userId: number, teamId: number, role?: string, joinedAt: Date }>;
  private resourceCategories: Map<number, ResourceCategory>;
  private resources: Map<number, Resource>;
  private events: Map<number, Event>;
  private mentors: Map<number, Mentor>;
  private messages: Map<number, Message>;
  
  private userId: number;
  private skillId: number;
  private ideaId: number;
  private commentId: number;
  private teamId: number;
  private resourceCategoryId: number;
  private resourceId: number;
  private eventId: number;
  private mentorId: number;
  private messageId: number;

  constructor() {
    this.users = new Map();
    this.skills = new Map();
    this.userSkills = new Map();
    this.ideas = new Map();
    this.ideaTags = new Map();
    this.comments = new Map();
    this.teams = new Map();
    this.teamMembers = new Map();
    this.resourceCategories = new Map();
    this.resources = new Map();
    this.events = new Map();
    this.mentors = new Map();
    this.messages = new Map();
    
    this.userId = 1;
    this.skillId = 1;
    this.ideaId = 1;
    this.commentId = 1;
    this.teamId = 1;
    this.resourceCategoryId = 1;
    this.resourceId = 1;
    this.eventId = 1;
    this.mentorId = 1;
    this.messageId = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }
  
  private initializeSampleData() {
    // Add skill categories
    const technicalSkills = this.createSkill({ name: "AI/Machine Learning", category: "Technical" });
    this.createSkill({ name: "UI/UX Design", category: "Technical" });
    this.createSkill({ name: "Blockchain", category: "Technical" });
    this.createSkill({ name: "Digital Marketing", category: "Business" });
    this.createSkill({ name: "Mobile Development", category: "Technical" });
    this.createSkill({ name: "Web Development", category: "Technical" });
    this.createSkill({ name: "Project Management", category: "Business" });
    this.createSkill({ name: "Data Analysis", category: "Technical" });
    this.createSkill({ name: "Content Writing", category: "Creative" });
    this.createSkill({ name: "Graphic Design", category: "Creative" });
    
    // Add resource categories
    const learningResources = this.createResourceCategory({ name: "Learning Paths" });
    const businessResources = this.createResourceCategory({ name: "Business Templates" });
    this.createResourceCategory({ name: "Legal Resources" });
    this.createResourceCategory({ name: "Tech Resources" });
    
    // Add resources
    this.createResource({
      title: "Getting Started with AI",
      description: "A comprehensive guide to AI for beginners",
      url: "https://example.com/ai-guide",
      categoryId: learningResources.id
    });
    
    this.createResource({
      title: "Business Plan Template",
      description: "Ready-to-use business plan template for startups",
      url: "https://example.com/business-plan",
      categoryId: businessResources.id
    });
    
    // Add events
    this.createEvent({
      title: "Startup Weekend Hackathon",
      description: "48-hour hackathon to build startup prototypes",
      date: new Date("2023-07-15"),
      location: "Virtual",
      type: "Hackathon"
    });
    
    this.createEvent({
      title: "Pitch Perfect: Idea Presentation Workshop",
      description: "Learn how to effectively pitch your startup idea",
      date: new Date("2023-07-22"),
      location: "Online Webinar",
      type: "Workshop"
    });
    
    this.createEvent({
      title: "VC Connect: Meet Investors",
      description: "Networking event with venture capitalists",
      date: new Date("2023-08-05"),
      location: "Bangalore Tech Hub",
      type: "Networking"
    });
    
    // Add mentors
    this.createMentor({
      name: "Ravi Kumar",
      expertise: "Technology Entrepreneurship",
      bio: "Founder of TechNova with 10+ years of experience in tech startups",
      company: "TechNova",
      position: "Founder & CEO",
      avatar: "",
      featured: true
    });
    
    this.createMentor({
      name: "Meera Iyer",
      expertise: "Product Management, Investments",
      bio: "VP Product at FinEdge and active angel investor in early-stage startups",
      company: "FinEdge",
      position: "VP Product",
      avatar: "",
      featured: true
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Skill methods
  async getSkills(): Promise<Skill[]> {
    return Array.from(this.skills.values());
  }
  
  async getSkillsByCategory(category: string): Promise<Skill[]> {
    return Array.from(this.skills.values()).filter(
      (skill) => skill.category === category,
    );
  }
  
  async createSkill(skill: InsertSkill): Promise<Skill> {
    const id = this.skillId++;
    const newSkill: Skill = { ...skill, id };
    this.skills.set(id, newSkill);
    return newSkill;
  }
  
  async getUserSkills(userId: number): Promise<Skill[]> {
    const skillIds = Array.from(this.userSkills.keys())
      .filter(key => key.startsWith(`${userId}-`))
      .map(key => parseInt(key.split('-')[1]));
    
    return skillIds.map(id => this.skills.get(id)!).filter(Boolean);
  }
  
  async addUserSkill(userId: number, skillId: number): Promise<void> {
    this.userSkills.set(`${userId}-${skillId}`, true);
  }
  
  async removeUserSkill(userId: number, skillId: number): Promise<void> {
    this.userSkills.delete(`${userId}-${skillId}`);
  }
  
  // Idea methods
  async getIdea(id: number): Promise<IdeaWithDetails | undefined> {
    const idea = this.ideas.get(id);
    if (!idea) return undefined;
    
    const user = await this.getUser(idea.userId);
    if (!user) return undefined;
    
    const tags = await this.getIdeaTags(id);
    
    return { ...idea, user, tags };
  }
  
  async getIdeas(limit?: number, featured?: boolean): Promise<IdeaWithUser[]> {
    let ideas = Array.from(this.ideas.values());
    
    if (featured !== undefined) {
      ideas = ideas.filter(idea => idea.featured === featured);
    }
    
    // Sort by most recent
    ideas = ideas.sort((a, b) => {
      const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(a.createdAt);
      const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(b.createdAt);
      return dateB.getTime() - dateA.getTime();
    });
    
    if (limit) {
      ideas = ideas.slice(0, limit);
    }
    
    // Fetch users for each idea
    const ideasWithUsers: IdeaWithUser[] = [];
    for (const idea of ideas) {
      const user = await this.getUser(idea.userId);
      if (user) {
        ideasWithUsers.push({ ...idea, user });
      }
    }
    
    return ideasWithUsers;
  }
  
  async getUserIdeas(userId: number): Promise<Idea[]> {
    return Array.from(this.ideas.values()).filter(
      (idea) => idea.userId === userId,
    );
  }
  
  async createIdea(idea: InsertIdea): Promise<Idea> {
    const id = this.ideaId++;
    const newIdea: Idea = { 
      ...idea, 
      id, 
      createdAt: new Date(),
      likes: 0,
      featured: false
    };
    this.ideas.set(id, newIdea);
    return newIdea;
  }
  
  async updateIdea(id: number, ideaData: Partial<Idea>): Promise<Idea | undefined> {
    const idea = this.ideas.get(id);
    if (!idea) return undefined;
    
    const updatedIdea = { ...idea, ...ideaData };
    this.ideas.set(id, updatedIdea);
    return updatedIdea;
  }
  
  async deleteIdea(id: number): Promise<boolean> {
    return this.ideas.delete(id);
  }
  
  async addIdeaTag(ideaTag: InsertIdeaTag): Promise<void> {
    this.ideaTags.set(`${ideaTag.ideaId}-${ideaTag.tag}`, ideaTag.tag);
  }
  
  async getIdeaTags(ideaId: number): Promise<string[]> {
    return Array.from(this.ideaTags.entries())
      .filter(([key]) => key.startsWith(`${ideaId}-`))
      .map(([_, tag]) => tag);
  }
  
  async likeIdea(id: number): Promise<Idea | undefined> {
    const idea = this.ideas.get(id);
    if (!idea) return undefined;
    
    const updatedIdea = { ...idea, likes: idea.likes + 1 };
    this.ideas.set(id, updatedIdea);
    return updatedIdea;
  }
  
  // Comment methods
  async getComments(ideaId: number): Promise<CommentWithUser[]> {
    const comments = Array.from(this.comments.values())
      .filter(comment => comment.ideaId === ideaId)
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(a.createdAt);
        const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(b.createdAt);
        return dateA.getTime() - dateB.getTime();
      });
    
    const commentsWithUsers: CommentWithUser[] = [];
    for (const comment of comments) {
      const user = await this.getUser(comment.userId);
      if (user) {
        commentsWithUsers.push({ ...comment, user });
      }
    }
    
    return commentsWithUsers;
  }
  
  async createComment(comment: InsertComment): Promise<Comment> {
    const id = this.commentId++;
    const newComment: Comment = { 
      ...comment, 
      id, 
      createdAt: new Date()
    };
    this.comments.set(id, newComment);
    return newComment;
  }
  
  // Team methods
  async getTeam(id: number): Promise<TeamWithMembers | undefined> {
    const team = this.teams.get(id);
    if (!team) return undefined;
    
    const members = Array.from(this.teamMembers.entries())
      .filter(([key]) => key.startsWith(`${id}-`))
      .map(([_, data]) => ({
        teamId: data.teamId,
        userId: data.userId,
        role: data.role,
        joinedAt: data.joinedAt,
        user: this.users.get(data.userId)!
      }))
      .filter(member => member.user !== undefined);
    
    return { ...team, members };
  }
  
  async getTeams(): Promise<Team[]> {
    return Array.from(this.teams.values());
  }
  
  async getUserTeams(userId: number): Promise<Team[]> {
    const teamIds = Array.from(this.teamMembers.entries())
      .filter(([_, data]) => data.userId === userId)
      .map(([_, data]) => data.teamId);
    
    return teamIds.map(id => this.teams.get(id)!).filter(Boolean);
  }
  
  async createTeam(team: InsertTeam): Promise<Team> {
    const id = this.teamId++;
    const newTeam: Team = { 
      ...team, 
      id, 
      createdAt: new Date()
    };
    this.teams.set(id, newTeam);
    
    // Automatically add the owner as a team member
    await this.addTeamMember({
      teamId: id,
      userId: team.ownerId,
      role: "Owner"
    });
    
    return newTeam;
  }
  
  async addTeamMember(teamMember: InsertTeamMember): Promise<void> {
    this.teamMembers.set(`${teamMember.teamId}-${teamMember.userId}`, {
      ...teamMember,
      joinedAt: new Date()
    });
  }
  
  async removeTeamMember(teamId: number, userId: number): Promise<boolean> {
    return this.teamMembers.delete(`${teamId}-${userId}`);
  }
  
  // Resource methods
  async getResourceCategories(): Promise<ResourceCategory[]> {
    return Array.from(this.resourceCategories.values());
  }
  
  async createResourceCategory(category: InsertResourceCategory): Promise<ResourceCategory> {
    const id = this.resourceCategoryId++;
    const newCategory: ResourceCategory = { ...category, id };
    this.resourceCategories.set(id, newCategory);
    return newCategory;
  }
  
  async getResources(categoryId?: number): Promise<Resource[]> {
    let resources = Array.from(this.resources.values());
    
    if (categoryId !== undefined) {
      resources = resources.filter(resource => resource.categoryId === categoryId);
    }
    
    return resources;
  }
  
  async createResource(resource: InsertResource): Promise<Resource> {
    const id = this.resourceId++;
    const newResource: Resource = { 
      ...resource, 
      id, 
      createdAt: new Date()
    };
    this.resources.set(id, newResource);
    return newResource;
  }
  
  // Event methods
  async getEvents(): Promise<Event[]> {
    return Array.from(this.events.values())
      .sort((a, b) => {
        const dateA = a.date instanceof Date ? a.date : new Date(a.date);
        const dateB = b.date instanceof Date ? b.date : new Date(b.date);
        return dateA.getTime() - dateB.getTime();
      });
  }
  
  async createEvent(event: InsertEvent): Promise<Event> {
    const id = this.eventId++;
    const newEvent: Event = { 
      ...event, 
      id, 
      createdAt: new Date()
    };
    this.events.set(id, newEvent);
    return newEvent;
  }
  
  // Mentor methods
  async getMentors(featured?: boolean): Promise<Mentor[]> {
    let mentors = Array.from(this.mentors.values());
    
    if (featured !== undefined) {
      mentors = mentors.filter(mentor => mentor.featured === featured);
    }
    
    return mentors;
  }
  
  async createMentor(mentor: InsertMentor): Promise<Mentor> {
    const id = this.mentorId++;
    const newMentor: Mentor = { 
      ...mentor, 
      id, 
      featured: mentor.featured || false
    };
    this.mentors.set(id, newMentor);
    return newMentor;
  }
  
  // Message methods
  async getUserMessages(userId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.senderId === userId || message.receiverId === userId)
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(a.createdAt);
        const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(b.createdAt);
        return dateB.getTime() - dateA.getTime();
      });
  }
  
  async createMessage(message: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const newMessage: Message = { 
      ...message, 
      id, 
      createdAt: new Date(),
      read: false
    };
    this.messages.set(id, newMessage);
    return newMessage;
  }
  
  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const message = this.messages.get(id);
    if (!message) return undefined;
    
    const updatedMessage = { ...message, read: true };
    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }
}

export const storage = new MemStorage();
