import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ZodError } from "zod";
import {
  insertUserSchema,
  insertIdeaSchema,
  insertCommentSchema,
  insertTeamSchema,
  insertTeamMemberSchema,
  insertResourceSchema,
  insertEventSchema,
  insertMentorSchema,
  insertMessageSchema,
} from "@shared/schema";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import bcrypt from "bcryptjs";
import MemoryStore from "memorystore";

// Initialize session store
const SessionStore = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure session
  app.use(session({
    secret: process.env.SESSION_SECRET || "catalyst-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: process.env.NODE_ENV === "production", maxAge: 86400000 }, // 1 day
    store: new SessionStore({ checkPeriod: 86400000 })
  }));

  // Configure passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure passport local strategy
  passport.use(new LocalStrategy(
    async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Incorrect username." });
        }
        
        const match = await bcrypt.compare(password, user.password);
        if (!match) {
          return done(null, false, { message: "Incorrect password." });
        }
        
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    }
  ));

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Middleware to handle zod validation errors
  const validateRequest = (schema: any) => {
    return (req: Request, res: Response, next: Function) => {
      try {
        schema.parse(req.body);
        next();
      } catch (error) {
        if (error instanceof ZodError) {
          res.status(400).json({ message: error.errors });
        } else {
          res.status(400).json({ message: "Invalid request data" });
        }
      }
    };
  };

  // Authentication routes
  app.post("/api/auth/register", validateRequest(insertUserSchema), async (req, res) => {
    try {
      const { username, email, password, ...rest } = req.body;
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Create user
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        ...rest
      });
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Error creating user" });
    }
  });

  app.post("/api/auth/login", passport.authenticate("local"), (req, res) => {
    // Remove password from response
    const { password: _, ...userWithoutPassword } = req.user as any;
    res.json(userWithoutPassword);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Error logging out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    // Remove password from response
    const { password: _, ...userWithoutPassword } = req.user as any;
    res.json(userWithoutPassword);
  });

  // User routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      // Get user skills
      const skills = await storage.getUserSkills(userId);
      
      res.json({ ...userWithoutPassword, skills });
    } catch (error) {
      res.status(500).json({ message: "Error fetching user" });
    }
  });

  app.put("/api/users/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = parseInt(req.params.id);
      const currentUser = req.user as any;
      
      // Ensure user can only update their own profile
      if (currentUser.id !== userId) {
        return res.status(403).json({ message: "Not authorized to update this user" });
      }
      
      const { password, ...updateData } = req.body;
      
      // If updating password, hash it
      if (password) {
        const hashedPassword = await bcrypt.hash(password, 10);
        updateData.password = hashedPassword;
      }
      
      const updatedUser = await storage.updateUser(userId, updateData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = updatedUser;
      
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Error updating user" });
    }
  });

  // Skill routes
  app.get("/api/skills", async (req, res) => {
    try {
      const skills = await storage.getSkills();
      res.json(skills);
    } catch (error) {
      res.status(500).json({ message: "Error fetching skills" });
    }
  });

  app.get("/api/skills/category/:category", async (req, res) => {
    try {
      const category = req.params.category;
      const skills = await storage.getSkillsByCategory(category);
      res.json(skills);
    } catch (error) {
      res.status(500).json({ message: "Error fetching skills by category" });
    }
  });

  app.post("/api/users/:id/skills/:skillId", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = parseInt(req.params.id);
      const skillId = parseInt(req.params.skillId);
      const currentUser = req.user as any;
      
      // Ensure user can only update their own skills
      if (currentUser.id !== userId) {
        return res.status(403).json({ message: "Not authorized to update this user's skills" });
      }
      
      await storage.addUserSkill(userId, skillId);
      
      // Get updated skills
      const skills = await storage.getUserSkills(userId);
      
      res.json(skills);
    } catch (error) {
      res.status(500).json({ message: "Error adding skill to user" });
    }
  });

  app.delete("/api/users/:id/skills/:skillId", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = parseInt(req.params.id);
      const skillId = parseInt(req.params.skillId);
      const currentUser = req.user as any;
      
      // Ensure user can only update their own skills
      if (currentUser.id !== userId) {
        return res.status(403).json({ message: "Not authorized to update this user's skills" });
      }
      
      await storage.removeUserSkill(userId, skillId);
      
      // Get updated skills
      const skills = await storage.getUserSkills(userId);
      
      res.json(skills);
    } catch (error) {
      res.status(500).json({ message: "Error removing skill from user" });
    }
  });

  // Idea routes
  app.get("/api/ideas", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const featured = req.query.featured === 'true' ? true : 
                       req.query.featured === 'false' ? false : undefined;
      
      const ideas = await storage.getIdeas(limit, featured);
      res.json(ideas);
    } catch (error) {
      res.status(500).json({ message: "Error fetching ideas" });
    }
  });

  app.get("/api/ideas/:id", async (req, res) => {
    try {
      const ideaId = parseInt(req.params.id);
      const idea = await storage.getIdea(ideaId);
      
      if (!idea) {
        return res.status(404).json({ message: "Idea not found" });
      }
      
      res.json(idea);
    } catch (error) {
      res.status(500).json({ message: "Error fetching idea" });
    }
  });

  app.post("/api/ideas", validateRequest(insertIdeaSchema), async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const currentUser = req.user as any;
      const ideaData = { ...req.body, userId: currentUser.id };
      
      const idea = await storage.createIdea(ideaData);
      
      // Add tags if provided
      if (req.body.tags && Array.isArray(req.body.tags)) {
        for (const tag of req.body.tags) {
          await storage.addIdeaTag({ ideaId: idea.id, tag });
        }
      }
      
      res.status(201).json(idea);
    } catch (error) {
      res.status(500).json({ message: "Error creating idea" });
    }
  });

  app.put("/api/ideas/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const ideaId = parseInt(req.params.id);
      const currentUser = req.user as any;
      
      // Check if idea exists
      const idea = await storage.getIdea(ideaId);
      if (!idea) {
        return res.status(404).json({ message: "Idea not found" });
      }
      
      // Ensure user can only update their own ideas
      if (idea.userId !== currentUser.id) {
        return res.status(403).json({ message: "Not authorized to update this idea" });
      }
      
      const updatedIdea = await storage.updateIdea(ideaId, req.body);
      
      if (!updatedIdea) {
        return res.status(404).json({ message: "Idea not found" });
      }
      
      res.json(updatedIdea);
    } catch (error) {
      res.status(500).json({ message: "Error updating idea" });
    }
  });

  app.delete("/api/ideas/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const ideaId = parseInt(req.params.id);
      const currentUser = req.user as any;
      
      // Check if idea exists
      const idea = await storage.getIdea(ideaId);
      if (!idea) {
        return res.status(404).json({ message: "Idea not found" });
      }
      
      // Ensure user can only delete their own ideas
      if (idea.userId !== currentUser.id) {
        return res.status(403).json({ message: "Not authorized to delete this idea" });
      }
      
      const deleted = await storage.deleteIdea(ideaId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Idea not found" });
      }
      
      res.json({ message: "Idea deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error deleting idea" });
    }
  });

  app.post("/api/ideas/:id/like", async (req, res) => {
    try {
      const ideaId = parseInt(req.params.id);
      
      // Check if idea exists
      const idea = await storage.getIdea(ideaId);
      if (!idea) {
        return res.status(404).json({ message: "Idea not found" });
      }
      
      const updatedIdea = await storage.likeIdea(ideaId);
      
      if (!updatedIdea) {
        return res.status(404).json({ message: "Idea not found" });
      }
      
      res.json(updatedIdea);
    } catch (error) {
      res.status(500).json({ message: "Error liking idea" });
    }
  });

  // Comment routes
  app.get("/api/ideas/:id/comments", async (req, res) => {
    try {
      const ideaId = parseInt(req.params.id);
      
      // Check if idea exists
      const idea = await storage.getIdea(ideaId);
      if (!idea) {
        return res.status(404).json({ message: "Idea not found" });
      }
      
      const comments = await storage.getComments(ideaId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Error fetching comments" });
    }
  });

  app.post("/api/ideas/:id/comments", validateRequest(insertCommentSchema), async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const ideaId = parseInt(req.params.id);
      const currentUser = req.user as any;
      
      // Check if idea exists
      const idea = await storage.getIdea(ideaId);
      if (!idea) {
        return res.status(404).json({ message: "Idea not found" });
      }
      
      const commentData = { 
        ...req.body, 
        userId: currentUser.id,
        ideaId
      };
      
      const comment = await storage.createComment(commentData);
      res.status(201).json(comment);
    } catch (error) {
      res.status(500).json({ message: "Error creating comment" });
    }
  });

  // Team routes
  app.get("/api/teams", async (req, res) => {
    try {
      const teams = await storage.getTeams();
      res.json(teams);
    } catch (error) {
      res.status(500).json({ message: "Error fetching teams" });
    }
  });

  app.get("/api/teams/:id", async (req, res) => {
    try {
      const teamId = parseInt(req.params.id);
      const team = await storage.getTeam(teamId);
      
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      
      res.json(team);
    } catch (error) {
      res.status(500).json({ message: "Error fetching team" });
    }
  });

  app.post("/api/teams", validateRequest(insertTeamSchema), async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const currentUser = req.user as any;
      const teamData = { ...req.body, ownerId: currentUser.id };
      
      const team = await storage.createTeam(teamData);
      res.status(201).json(team);
    } catch (error) {
      res.status(500).json({ message: "Error creating team" });
    }
  });

  app.post("/api/teams/:id/members", validateRequest(insertTeamMemberSchema), async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const teamId = parseInt(req.params.id);
      const currentUser = req.user as any;
      
      // Check if team exists
      const team = await storage.getTeam(teamId);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      
      // Ensure only the team owner can add members
      if (team.ownerId !== currentUser.id) {
        return res.status(403).json({ message: "Not authorized to add members to this team" });
      }
      
      const memberData = { ...req.body, teamId };
      
      await storage.addTeamMember(memberData);
      
      // Get updated team
      const updatedTeam = await storage.getTeam(teamId);
      res.json(updatedTeam);
    } catch (error) {
      res.status(500).json({ message: "Error adding team member" });
    }
  });

  app.delete("/api/teams/:id/members/:userId", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const teamId = parseInt(req.params.id);
      const userId = parseInt(req.params.userId);
      const currentUser = req.user as any;
      
      // Check if team exists
      const team = await storage.getTeam(teamId);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      
      // Ensure only the team owner can remove members, or users can remove themselves
      if (team.ownerId !== currentUser.id && userId !== currentUser.id) {
        return res.status(403).json({ message: "Not authorized to remove this member" });
      }
      
      const removed = await storage.removeTeamMember(teamId, userId);
      
      if (!removed) {
        return res.status(404).json({ message: "Team member not found" });
      }
      
      // Get updated team
      const updatedTeam = await storage.getTeam(teamId);
      res.json(updatedTeam);
    } catch (error) {
      res.status(500).json({ message: "Error removing team member" });
    }
  });

  // Resource routes
  app.get("/api/resources/categories", async (req, res) => {
    try {
      const categories = await storage.getResourceCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Error fetching resource categories" });
    }
  });

  app.get("/api/resources", async (req, res) => {
    try {
      const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;
      const resources = await storage.getResources(categoryId);
      res.json(resources);
    } catch (error) {
      res.status(500).json({ message: "Error fetching resources" });
    }
  });

  app.post("/api/resources", validateRequest(insertResourceSchema), async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Only allow admins to create resources in the future
      
      const resource = await storage.createResource(req.body);
      res.status(201).json(resource);
    } catch (error) {
      res.status(500).json({ message: "Error creating resource" });
    }
  });

  // Event routes
  app.get("/api/events", async (req, res) => {
    try {
      const events = await storage.getEvents();
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Error fetching events" });
    }
  });

  app.post("/api/events", validateRequest(insertEventSchema), async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Only allow admins to create events in the future
      
      const event = await storage.createEvent(req.body);
      res.status(201).json(event);
    } catch (error) {
      res.status(500).json({ message: "Error creating event" });
    }
  });

  // Mentor routes
  app.get("/api/mentors", async (req, res) => {
    try {
      const featured = req.query.featured === 'true' ? true : 
                      req.query.featured === 'false' ? false : undefined;
      
      const mentors = await storage.getMentors(featured);
      res.json(mentors);
    } catch (error) {
      res.status(500).json({ message: "Error fetching mentors" });
    }
  });

  app.post("/api/mentors", validateRequest(insertMentorSchema), async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Only allow admins to create mentors in the future
      
      const mentor = await storage.createMentor(req.body);
      res.status(201).json(mentor);
    } catch (error) {
      res.status(500).json({ message: "Error creating mentor" });
    }
  });

  // Message routes
  app.get("/api/messages", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const currentUser = req.user as any;
      const messages = await storage.getUserMessages(currentUser.id);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Error fetching messages" });
    }
  });

  app.post("/api/messages", validateRequest(insertMessageSchema), async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const currentUser = req.user as any;
      const messageData = { ...req.body, senderId: currentUser.id };
      
      const message = await storage.createMessage(messageData);
      res.status(201).json(message);
    } catch (error) {
      res.status(500).json({ message: "Error creating message" });
    }
  });

  app.put("/api/messages/:id/read", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const messageId = parseInt(req.params.id);
      const currentUser = req.user as any;
      
      // Only the receiver can mark a message as read
      const messages = await storage.getUserMessages(currentUser.id);
      const message = messages.find(msg => msg.id === messageId && msg.receiverId === currentUser.id);
      
      if (!message) {
        return res.status(404).json({ message: "Message not found or not authorized" });
      }
      
      const updatedMessage = await storage.markMessageAsRead(messageId);
      
      if (!updatedMessage) {
        return res.status(404).json({ message: "Message not found" });
      }
      
      res.json(updatedMessage);
    } catch (error) {
      res.status(500).json({ message: "Error marking message as read" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
