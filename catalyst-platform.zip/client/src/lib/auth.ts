import { apiRequest } from "./queryClient";

export interface User {
  id: number;
  username: string;
  email: string;
  name?: string;
  college?: string;
  branch?: string;
  year?: string;
  bio?: string;
  avatar?: string;
  entrepreneurialStatus?: string;
}

export async function login(username: string, password: string): Promise<User> {
  try {
    const response = await apiRequest("POST", "/api/auth/login", { username, password });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || "Login failed");
    }
    
    return response.json();
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error("An unexpected error occurred during login");
  }
}

export async function register(userData: any): Promise<User> {
  try {
    const response = await apiRequest("POST", "/api/auth/register", userData);
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || "Registration failed");
    }
    
    return response.json();
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error("An unexpected error occurred during registration");
  }
}

export async function logout(): Promise<void> {
  try {
    const response = await apiRequest("POST", "/api/auth/logout", {});
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || "Logout failed");
    }
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error("An unexpected error occurred during logout");
  }
}

export async function getCurrentUser(): Promise<User | null> {
  try {
    const response = await fetch("/api/auth/me", { credentials: "include" });
    
    if (!response.ok) {
      if (response.status === 401) {
        return null;
      }
      const error = await response.json();
      throw new Error(error.message || "Failed to get current user");
    }
    
    return response.json();
  } catch (error) {
    console.error("Error fetching current user:", error);
    return null;
  }
}
