import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface MentorCardProps {
  mentor: {
    id: number;
    name: string;
    expertise: string;
    bio: string;
    company?: string;
    position?: string;
    avatar?: string;
    featured?: boolean;
  };
  featured?: boolean;
  className?: string;
}

const MentorCard = ({ mentor, featured = false, className }: MentorCardProps) => {
  // Extract first letter of first and last name for avatar fallback
  const getInitials = (name: string) => {
    const parts = name.split(' ');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[parts.length - 1][0]}`;
    }
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <Card className={cn(
      "overflow-hidden",
      featured && "border-primary",
      className
    )}>
      <CardHeader className="pt-6 pb-0 px-6">
        <div className="flex items-start justify-between">
          <Avatar className="h-16 w-16">
            <AvatarImage src={mentor.avatar} alt={mentor.name} />
            <AvatarFallback className="text-lg">{getInitials(mentor.name)}</AvatarFallback>
          </Avatar>
          
          {featured && (
            <Badge className="bg-primary text-white">
              Featured Mentor
            </Badge>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="pt-4 px-6 pb-6">
        <h3 className="text-lg font-semibold mb-1">{mentor.name}</h3>
        
        {mentor.company && mentor.position && (
          <p className="text-sm text-neutral-medium mb-2">
            {mentor.position} at {mentor.company}
          </p>
        )}
        
        <div className="mb-3">
          <Badge variant="outline" className="bg-primary/10">
            {mentor.expertise}
          </Badge>
        </div>
        
        <p className="text-sm text-neutral-medium mb-4 line-clamp-3">{mentor.bio}</p>
        
        <div className="flex space-x-2">
          <Button className="flex-1">
            Request Mentorship
          </Button>
          <Button variant="outline" className="flex-1">
            View Profile
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default MentorCard;
