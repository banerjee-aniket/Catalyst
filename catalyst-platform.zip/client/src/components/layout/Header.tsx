import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Search, Bell, MessageSquare, Menu } from "lucide-react";

const Header = () => {
  const [location, setLocation] = useLocation();
  const { user, logout } = useAuth();

  const handleLogout = async () => {
    await logout();
    setLocation("/login");
  };

  return (
    <header className="bg-white border-b border-gray-200">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center md:hidden">
            <button type="button" className="text-neutral-medium hover:text-neutral-dark focus:outline-none">
              <Menu className="h-6 w-6" />
            </button>
            <div className="ml-3">
              <h1 className="text-xl font-bold text-primary">Catalyst</h1>
            </div>
          </div>
          
          <div className="flex-1 flex items-center justify-center md:justify-end">
            <div className="max-w-lg w-full md:max-w-xs">
              <label htmlFor="search" className="sr-only">Search</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <Search className="h-4 w-4 text-neutral-light" />
                </div>
                <Input 
                  id="search" 
                  name="search" 
                  className="block w-full pl-10 pr-3 py-2" 
                  placeholder="Search ideas, skills, users..." 
                  type="search"
                />
              </div>
            </div>
            
            {user ? (
              <div className="ml-4 flex items-center md:ml-6">
                <Button variant="ghost" size="icon" className="p-1 text-neutral-medium rounded-full hover:text-neutral-dark">
                  <Bell className="h-5 w-5" />
                </Button>
                
                <Button variant="ghost" size="icon" className="ml-3 p-1 text-neutral-medium rounded-full hover:text-neutral-dark">
                  <MessageSquare className="h-5 w-5" />
                </Button>
                
                <div className="ml-3 relative">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="p-0 flex">
                        <Avatar className="h-8 w-8 rounded-full">
                          <AvatarImage src={user.avatar} alt={user.name} />
                          <AvatarFallback>{user.name?.charAt(0) || user.username.charAt(0)}</AvatarFallback>
                        </Avatar>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>My Account</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem asChild>
                        <Link href="/profile">Profile</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/settings">Settings</Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleLogout}>
                        Logout
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            ) : (
              <div className="ml-4 flex items-center md:ml-6">
                <Button variant="ghost" asChild>
                  <Link href="/login">Login</Link>
                </Button>
                <Button asChild className="ml-2">
                  <Link href="/register">Register</Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
