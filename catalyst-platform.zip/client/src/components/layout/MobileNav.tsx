import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

const MobileNav = () => {
  const [location] = useLocation();
  const { user } = useAuth();
  
  if (!user) return null;

  const navItems = [
    { name: "Home", path: "/", icon: "fas fa-home" },
    { name: "Ideas", path: "/ideas", icon: "fas fa-lightbulb" },
    { name: "Teams", path: "/teams", icon: "fas fa-users" },
    { name: "Resources", path: "/resources", icon: "fas fa-book" },
    { name: "Profile", path: "/profile", icon: "fas fa-user" }
  ];

  return (
    <nav className="md:hidden bg-white border-t border-gray-200 fixed bottom-0 w-full">
      <div className="flex justify-around">
        {navItems.map(item => (
          <Link 
            key={item.path}
            href={item.path}
            className="flex flex-col items-center py-2 px-3"
          >
            <i className={cn(
              item.icon, 
              "text-xl",
              location === item.path ? "text-primary" : "text-neutral-medium"
            )}></i>
            <span className={cn(
              "text-xs mt-1",
              location === item.path ? "text-primary" : "text-neutral-medium"
            )}>
              {item.name}
            </span>
          </Link>
        ))}
      </div>
    </nav>
  );
};

export default MobileNav;
