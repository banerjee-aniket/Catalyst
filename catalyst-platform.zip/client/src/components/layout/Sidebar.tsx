import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";

const Sidebar = () => {
  const [location] = useLocation();
  const { user } = useAuth();
  
  if (!user) return null;

  const navItems = [
    { name: "Home", path: "/", icon: "fas fa-home" },
    { name: "My Profile", path: "/profile", icon: "fas fa-user" },
    { name: "Idea Marketplace", path: "/ideas", icon: "fas fa-lightbulb" },
    { name: "Find Teammates", path: "/teams", icon: "fas fa-users" },
    { name: "Resources", path: "/resources", icon: "fas fa-book" },
    { name: "Mentorship", path: "/mentors", icon: "fas fa-user-tie" },
    { name: "Events", path: "/events", icon: "fas fa-calendar-alt" }
  ];

  return (
    <aside className="hidden md:flex md:w-64 flex-col bg-white border-r border-gray-200 overflow-y-auto">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center">
          <div className="rounded-lg bg-primary p-2 mr-2">
            <i className="fas fa-rocket text-white"></i>
          </div>
          <h1 className="text-xl font-bold text-primary">Catalyst</h1>
        </div>
      </div>
      
      <nav className="flex-1 px-2 py-4 space-y-1">
        {navItems.map(item => (
          <Link 
            key={item.path}
            href={item.path}
            className={cn(
              "flex items-center px-4 py-2 rounded-md group",
              location === item.path 
                ? "text-neutral-dark bg-neutral-lightest" 
                : "text-neutral-medium hover:bg-neutral-lightest"
            )}
          >
            <i className={cn(
              item.icon, 
              "mr-3",
              location === item.path ? "text-primary" : "text-neutral-medium"
            )}></i>
            <span className={location === item.path ? "font-medium" : ""}>
              {item.name}
            </span>
          </Link>
        ))}
      </nav>
      
      <div className="p-4 border-t border-gray-200">
        <Link href="/settings" className="flex items-center text-neutral-medium hover:text-neutral-dark">
          <i className="fas fa-cog mr-2"></i>
          <span>Settings</span>
        </Link>
        <Link href="#" onClick={(e) => { 
          e.preventDefault();
          fetch('/api/auth/logout', { method: 'POST', credentials: 'include' })
            .then(() => window.location.href = '/login');
        }} className="flex items-center mt-3 text-neutral-medium hover:text-neutral-dark">
          <i className="fas fa-sign-out-alt mr-2"></i>
          <span>Logout</span>
        </Link>
      </div>
    </aside>
  );
};

export default Sidebar;
