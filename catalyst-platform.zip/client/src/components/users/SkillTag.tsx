import { cn } from "@/lib/utils";
import { X } from "lucide-react";

const categoryColors: Record<string, { bg: string, text: string }> = {
  "Technical": { bg: "bg-blue-100", text: "text-blue-800" },
  "Business": { bg: "bg-green-100", text: "text-green-800" },
  "Creative": { bg: "bg-purple-100", text: "text-purple-800" },
  "default": { bg: "bg-neutral-100", text: "text-neutral-800" }
};

interface SkillTagProps {
  skill: {
    id: number;
    name: string;
    category?: string;
  };
  removable?: boolean;
  onRemove?: () => void;
  className?: string;
}

const SkillTag = ({ skill, removable = false, onRemove, className }: SkillTagProps) => {
  const colors = skill.category && categoryColors[skill.category] 
    ? categoryColors[skill.category] 
    : categoryColors.default;
  
  return (
    <span
      className={cn(
        "skill-tag inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium",
        colors.bg,
        colors.text,
        removable && "pr-1",
        className
      )}
    >
      {skill.name}
      {removable && (
        <button
          type="button"
          className={cn(
            "ml-1 rounded-full p-0.5 hover:bg-white/20",
            "focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-transparent",
            `focus:ring-${colors.text.split('-')[1]}-500`
          )}
          onClick={onRemove}
          aria-label={`Remove ${skill.name} skill`}
        >
          <X className="h-3 w-3" />
        </button>
      )}
    </span>
  );
};

export default SkillTag;
