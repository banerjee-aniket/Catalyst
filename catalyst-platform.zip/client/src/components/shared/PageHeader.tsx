import { cn } from "@/lib/utils";

interface PageHeaderProps {
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}

const PageHeader = ({
  title,
  description,
  action,
  className,
}: PageHeaderProps) => {
  return (
    <div className={cn(
      "pb-5 mb-5 flex flex-col sm:flex-row sm:items-center sm:justify-between",
      className
    )}>
      <div>
        <h1 className="text-2xl font-bold text-neutral-dark">{title}</h1>
        {description && (
          <p className="mt-1 text-sm text-neutral-medium">{description}</p>
        )}
      </div>
      
      {action && (
        <div className="mt-4 sm:mt-0 sm:ml-4">
          {action}
        </div>
      )}
    </div>
  );
};

export default PageHeader;
