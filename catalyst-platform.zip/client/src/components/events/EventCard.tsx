import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { Calendar, MapPin } from "lucide-react";

interface EventCardProps {
  event: {
    id: number;
    title: string;
    description: string;
    date: string | Date;
    location: string;
    type: string;
  };
  isPast?: boolean;
  className?: string;
}

const EventCard = ({ event, isPast = false, className }: EventCardProps) => {
  // Determine border color based on event type
  const getBorderColor = (type: string) => {
    const typeLower = type.toLowerCase();
    if (typeLower.includes('hackathon')) return 'border-primary';
    if (typeLower.includes('workshop')) return 'border-accent';
    if (typeLower.includes('networking')) return 'border-secondary';
    return 'border-neutral-light';
  };

  return (
    <Card className={cn(
      "border-l-4",
      getBorderColor(event.type),
      isPast && "opacity-75",
      className
    )}>
      <CardContent className="p-4">
        {isPast && (
          <div className="mb-2">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-neutral-100 text-neutral-800">
              Past Event
            </span>
          </div>
        )}
        
        <h3 className="font-medium text-base mb-2">{event.title}</h3>
        <p className="text-sm text-neutral-medium mb-3 line-clamp-2">{event.description}</p>
        
        <div className="space-y-2">
          <div className="flex items-center text-xs text-neutral-medium">
            <Calendar className="h-3.5 w-3.5 mr-1.5" />
            <span>{format(new Date(event.date), "MMMM d, yyyy")}</span>
          </div>
          
          <div className="flex items-center text-xs text-neutral-medium">
            <MapPin className="h-3.5 w-3.5 mr-1.5" />
            <span>{event.location}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default EventCard;
