import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface IdeaCardProps {
  idea: {
    id: number;
    title: string;
    description: string;
    likes: number;
    featured?: boolean;
    tags?: string[];
    user: {
      id: number;
      name: string;
      username: string;
      college?: string;
      avatar?: string;
    };
  };
  featured?: boolean;
  className?: string;
  showActions?: boolean;
}

const IdeaCard = ({ idea, featured = false, className, showActions = false }: IdeaCardProps) => {
  return (
    <Card className={cn("idea-card overflow-hidden", className)}>
      <CardContent className="p-5">
        <div className="flex justify-between items-start">
          <div className="flex items-center">
            <Avatar className="h-8 w-8">
              <AvatarImage src={idea.user.avatar} alt={idea.user.name} />
              <AvatarFallback>{idea.user.name?.charAt(0) || idea.user.username.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <h3 className="text-sm font-medium">{idea.user.name}</h3>
              <p className="text-xs text-neutral-light">{idea.user.college}</p>
            </div>
          </div>
          
          {featured && (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-light text-white">
              Featured
            </span>
          )}
        </div>
        
        <h2 className="mt-3 text-base font-semibold">{idea.title}</h2>
        <p className="mt-1 text-neutral-medium text-sm">{idea.description}</p>
        
        {idea.tags && idea.tags.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {idea.tags.map((tag) => (
              <span 
                key={tag} 
                className="skill-tag inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-blue-100 text-blue-800"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}
        
        <div className="mt-4 flex justify-between items-center">
          {showActions ? (
            <>
              <div className="flex space-x-4 text-neutral-medium text-sm">
                <button className="flex items-center space-x-1 hover:text-primary">
                  <i className="fas fa-thumbs-up"></i>
                  <span>{idea.likes}</span>
                </button>
                <button className="flex items-center space-x-1 hover:text-primary">
                  <i className="fas fa-comment"></i>
                </button>
              </div>
              
              <Button asChild variant="outline">
                <Link href={`/ideas/${idea.id}`}>
                  <i className="fas fa-lightbulb mr-1"></i>
                  Learn More
                </Link>
              </Button>
            </>
          ) : (
            <Button asChild className="w-full mt-2">
              <Link href={`/ideas/${idea.id}`}>
                View Details
              </Link>
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default IdeaCard;
