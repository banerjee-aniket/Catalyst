import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Event } from "@shared/schema";
import PageHeader from "@/components/shared/PageHeader";
import EventCard from "@/components/events/EventCard";
import { format, isFuture, isPast } from "date-fns";
import { Search, Calendar, MapPin, Users } from "lucide-react";

const Events = () => {
  const [searchTerm, setSearchTerm] = useState("");
  
  const { data: events = [], isLoading } = useQuery<Event[]>({
    queryKey: ["/api/events"],
    queryFn: async () => {
      const res = await fetch("/api/events");
      return res.json();
    },
  });
  
  // Filter events based on search term
  const filteredEvents = events.filter(event => {
    if (!searchTerm) return true;
    const searchLower = searchTerm.toLowerCase();
    return (
      event.title.toLowerCase().includes(searchLower) ||
      event.description.toLowerCase().includes(searchLower) ||
      event.location.toLowerCase().includes(searchLower) ||
      event.type.toLowerCase().includes(searchLower)
    );
  });
  
  // Separate upcoming and past events
  const upcomingEvents = filteredEvents.filter(event => 
    isFuture(new Date(event.date))
  ).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  const pastEvents = filteredEvents.filter(event => 
    isPast(new Date(event.date))
  ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <>
      <PageHeader
        title="Events"
        description="Discover hackathons, workshops, and networking opportunities"
      />
      
      <div className="mb-6">
        <div className="relative max-w-md mx-auto">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search className="h-4 w-4 text-neutral-light" />
          </div>
          <Input
            type="search"
            placeholder="Search events by title, location, or type..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      {isLoading ? (
        <div className="text-center py-8">Loading events...</div>
      ) : filteredEvents.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-neutral-medium">
            {searchTerm 
              ? `No events found matching "${searchTerm}".` 
              : "No events available yet."}
          </p>
          {searchTerm && (
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => setSearchTerm("")}
            >
              Clear Search
            </Button>
          )}
        </div>
      ) : (
        <Tabs defaultValue="upcoming">
          <TabsList className="mb-6">
            <TabsTrigger value="upcoming">Upcoming Events</TabsTrigger>
            <TabsTrigger value="past">Past Events</TabsTrigger>
          </TabsList>
          
          <TabsContent value="upcoming">
            {upcomingEvents.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-neutral-medium">No upcoming events found.</p>
              </div>
            ) : (
              <div className="space-y-6">
                <FeaturedEvent event={upcomingEvents[0]} />
                
                {upcomingEvents.length > 1 && (
                  <div>
                    <h2 className="text-xl font-semibold mb-4">More Upcoming Events</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {upcomingEvents.slice(1).map(event => (
                        <EventCard key={event.id} event={event} className="h-full" />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="past">
            {pastEvents.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-neutral-medium">No past events found.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pastEvents.map(event => (
                  <EventCard key={event.id} event={event} isPast className="h-full" />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}
    </>
  );
};

interface FeaturedEventProps {
  event: Event;
}

const FeaturedEvent = ({ event }: FeaturedEventProps) => {
  return (
    <Card className="overflow-hidden">
      <div className="md:flex">
        <div className="md:w-2/3 p-6">
          <CardHeader className="p-0 pb-4">
            <div className="flex items-center mb-2">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-light text-white">
                Featured Event
              </span>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-neutral-lightest text-neutral-dark ml-2">
                {event.type}
              </span>
            </div>
            <CardTitle className="text-2xl">{event.title}</CardTitle>
            <CardDescription className="text-base mt-2">
              {event.description}
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0 space-y-4">
            <div className="flex items-center text-neutral-medium">
              <Calendar className="h-4 w-4 mr-2" />
              <span>{format(new Date(event.date), "MMMM d, yyyy 'at' h:mm a")}</span>
            </div>
            <div className="flex items-center text-neutral-medium">
              <MapPin className="h-4 w-4 mr-2" />
              <span>{event.location}</span>
            </div>
          </CardContent>
          <CardFooter className="p-0 pt-6">
            <Button size="lg">
              Register Now
            </Button>
          </CardFooter>
        </div>
        <div className="md:w-1/3 bg-gradient-to-br from-primary-light to-primary-dark flex items-center justify-center p-6">
          <div className="text-center text-white">
            <div className="text-6xl font-bold">
              {format(new Date(event.date), "d")}
            </div>
            <div className="text-xl font-medium uppercase">
              {format(new Date(event.date), "MMM")}
            </div>
            <div className="mt-4 flex items-center justify-center">
              <Users className="h-5 w-5 mr-2" />
              <span>Join 50+ others</span>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default Events;
