import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import IdeaCard from "@/components/ideas/IdeaCard";
import PageHeader from "@/components/shared/PageHeader";
import { Idea } from "@shared/schema";
import { Search } from "lucide-react";

const Ideas = () => {
  const [filter, setFilter] = useState("all");
  const [sort, setSort] = useState("latest");
  const [searchTerm, setSearchTerm] = useState("");

  const { data: ideas = [], isLoading } = useQuery<(Idea & { user: any; tags: string[] })[]>({
    queryKey: ["/api/ideas"],
    queryFn: async () => {
      const res = await fetch("/api/ideas");
      return res.json();
    },
  });

  // Filter and sort ideas
  const filteredIdeas = ideas.filter(idea => {
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      return (
        idea.title.toLowerCase().includes(searchLower) ||
        idea.description.toLowerCase().includes(searchLower) ||
        (idea.tags && idea.tags.some(tag => tag.toLowerCase().includes(searchLower)))
      );
    }
    return true;
  });

  const sortedIdeas = [...filteredIdeas].sort((a, b) => {
    if (sort === "latest") {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    } else if (sort === "popular") {
      return b.likes - a.likes;
    }
    return 0;
  });

  const featuredIdeas = sortedIdeas.filter(idea => idea.featured);
  const nonFeaturedIdeas = sortedIdeas.filter(idea => !idea.featured);

  return (
    <>
      <PageHeader
        title="Idea Marketplace"
        description="Discover innovative ideas from fellow students or share your own"
        action={
          <Button asChild>
            <Link href="/ideas/create">
              <i className="fas fa-plus mr-2"></i>
              Post Your Idea
            </Link>
          </Button>
        }
      />
      
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search className="h-4 w-4 text-neutral-light" />
            </div>
            <Input
              type="search"
              placeholder="Search ideas by title, description, or tags..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex gap-2">
            <Select defaultValue={sort} onValueChange={setSort}>
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="latest">Latest</SelectItem>
                <SelectItem value="popular">Most Liked</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <Tabs defaultValue="all" onValueChange={setFilter}>
          <TabsList className="mb-6">
            <TabsTrigger value="all">All Ideas</TabsTrigger>
            <TabsTrigger value="featured">Featured</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            {isLoading ? (
              <div className="text-center py-8">Loading ideas...</div>
            ) : sortedIdeas.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-neutral-medium mb-4">No ideas found matching your search.</p>
                <Button variant="outline" onClick={() => setSearchTerm("")}>Clear Search</Button>
              </div>
            ) : (
              <div className="space-y-4">
                {featuredIdeas.length > 0 && (
                  <div className="mb-6">
                    <h2 className="text-lg font-semibold mb-3">Featured Ideas</h2>
                    <div className="space-y-4">
                      {featuredIdeas.map(idea => (
                        <IdeaCard 
                          key={idea.id} 
                          idea={idea} 
                          featured
                          showActions
                        />
                      ))}
                    </div>
                  </div>
                )}
                
                {nonFeaturedIdeas.length > 0 && (
                  <div>
                    {featuredIdeas.length > 0 && (
                      <h2 className="text-lg font-semibold mb-3">All Ideas</h2>
                    )}
                    <div className="space-y-4">
                      {nonFeaturedIdeas.map(idea => (
                        <IdeaCard 
                          key={idea.id} 
                          idea={idea}
                          showActions
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="featured">
            {isLoading ? (
              <div className="text-center py-8">Loading ideas...</div>
            ) : featuredIdeas.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-neutral-medium">No featured ideas found.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {featuredIdeas.map(idea => (
                  <IdeaCard 
                    key={idea.id} 
                    idea={idea}
                    featured
                    showActions
                  />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default Ideas;
