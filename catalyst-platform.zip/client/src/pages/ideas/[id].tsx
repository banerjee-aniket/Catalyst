import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { insertCommentSchema } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import PageHeader from "@/components/shared/PageHeader";
import SkillTag from "@/components/users/SkillTag";
import { apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";

const formSchema = insertCommentSchema.pick({ content: true });

type FormValues = z.infer<typeof formSchema>;

const IdeaDetails = ({ id }: { id: string }) => {
  const ideaId = parseInt(id);
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isLiking, setIsLiking] = useState(false);

  // Fetch idea details
  const { data: idea, isLoading: isLoadingIdea } = useQuery({
    queryKey: ["/api/ideas", ideaId],
    queryFn: async () => {
      const res = await fetch(`/api/ideas/${ideaId}`);
      if (!res.ok) throw new Error("Failed to load idea");
      return res.json();
    },
  });

  // Fetch comments
  const { data: comments = [], isLoading: isLoadingComments } = useQuery({
    queryKey: ["/api/ideas", ideaId, "comments"],
    queryFn: async () => {
      const res = await fetch(`/api/ideas/${ideaId}/comments`);
      if (!res.ok) throw new Error("Failed to load comments");
      return res.json();
    },
    enabled: !!ideaId,
  });

  // Form for adding comments
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      content: "",
    },
  });

  // Like idea mutation
  const likeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/ideas/${ideaId}/like`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ideas", ideaId] });
      setIsLiking(false);
    },
    onError: (error: any) => {
      toast({
        title: "Failed to like idea",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
      setIsLiking(false);
    },
  });

  // Add comment mutation
  const commentMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const response = await apiRequest("POST", `/api/ideas/${ideaId}/comments`, values);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ideas", ideaId, "comments"] });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to add comment",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    },
  });

  const handleLike = () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to like ideas",
        variant: "destructive",
      });
      return;
    }
    
    setIsLiking(true);
    likeMutation.mutate();
  };

  const onSubmit = (values: FormValues) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to comment",
        variant: "destructive",
      });
      return;
    }
    
    commentMutation.mutate(values);
  };

  if (isLoadingIdea) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <p>Loading idea details...</p>
      </div>
    );
  }

  if (!idea) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Idea not found</h2>
          <p className="text-neutral-medium mb-4">The idea you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link href="/ideas">Back to Ideas</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <PageHeader
        title={idea.title}
        description="Idea details and discussion"
        action={
          <Button asChild variant="outline">
            <Link href="/ideas">
              <i className="fas fa-arrow-left mr-2"></i>
              Back to Ideas
            </Link>
          </Button>
        }
      />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          {/* Idea details */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={idea.user.avatar} alt={idea.user.name} />
                    <AvatarFallback>{idea.user.name?.charAt(0) || idea.user.username.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium">{idea.user.name}</h3>
                    <p className="text-xs text-neutral-light">{idea.user.college}</p>
                  </div>
                </div>
                
                {idea.featured && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-light text-white">
                    Featured
                  </span>
                )}
              </div>
              
              <h1 className="text-xl font-semibold mb-3">{idea.title}</h1>
              <p className="text-neutral-medium mb-4">{idea.description}</p>
              
              {idea.problem && (
                <div className="mb-4">
                  <h3 className="text-sm font-semibold mb-1">Problem</h3>
                  <p className="text-sm text-neutral-medium">{idea.problem}</p>
                </div>
              )}
              
              {idea.solution && (
                <div className="mb-4">
                  <h3 className="text-sm font-semibold mb-1">Solution</h3>
                  <p className="text-sm text-neutral-medium">{idea.solution}</p>
                </div>
              )}
              
              {idea.targetAudience && (
                <div className="mb-4">
                  <h3 className="text-sm font-semibold mb-1">Target Audience</h3>
                  <p className="text-sm text-neutral-medium">{idea.targetAudience}</p>
                </div>
              )}
              
              {idea.tags && idea.tags.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {idea.tags.map((tag: string) => (
                    <span 
                      key={tag} 
                      className="skill-tag inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-blue-100 text-blue-800"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
              
              <div className="mt-5 flex justify-between items-center pt-4 border-t">
                <div className="flex space-x-4 text-neutral-medium text-sm">
                  <button 
                    className="flex items-center space-x-1 hover:text-primary"
                    onClick={handleLike}
                    disabled={isLiking}
                  >
                    <i className="fas fa-thumbs-up"></i>
                    <span>{idea.likes}</span>
                  </button>
                  <button className="flex items-center space-x-1 hover:text-primary">
                    <i className="fas fa-comment"></i>
                    <span>{comments.length}</span>
                  </button>
                  <button className="flex items-center space-x-1 hover:text-primary">
                    <i className="fas fa-share"></i>
                  </button>
                </div>
                
                <Button className="inline-flex items-center">
                  <i className="fas fa-user-plus mr-1"></i>
                  Join Team
                </Button>
              </div>
            </CardContent>
          </Card>
          
          {/* Comments section */}
          <Card>
            <CardHeader>
              <h2 className="text-lg font-semibold">Discussion ({comments.length})</h2>
            </CardHeader>
            <CardContent>
              {/* Add comment form */}
              {user && (
                <div className="mb-6">
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="content"
                        render={({ field }) => (
                          <FormItem>
                            <div className="flex items-start gap-3">
                              <Avatar className="h-8 w-8 mt-1">
                                <AvatarImage src={user.avatar} alt={user.name} />
                                <AvatarFallback>{user.name?.charAt(0) || user.username.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1">
                                <FormControl>
                                  <Textarea 
                                    placeholder="Add to the discussion..." 
                                    className="min-h-[80px]"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                                <div className="flex justify-end mt-2">
                                  <Button 
                                    type="submit" 
                                    size="sm"
                                    disabled={commentMutation.isPending}
                                  >
                                    {commentMutation.isPending ? "Posting..." : "Post Comment"}
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </FormItem>
                        )}
                      />
                    </form>
                  </Form>
                </div>
              )}
              
              {/* Comments list */}
              {isLoadingComments ? (
                <p>Loading comments...</p>
              ) : comments.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-neutral-medium">No comments yet. Be the first to add to the discussion!</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {comments.map((comment: any) => (
                    <div key={comment.id} className="flex gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={comment.user.avatar} alt={comment.user.name} />
                        <AvatarFallback>{comment.user.name?.charAt(0) || comment.user.username.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-medium">{comment.user.name}</h4>
                          <span className="text-xs text-neutral-light">
                            {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                          </span>
                        </div>
                        <p className="mt-1 text-sm text-neutral-medium">{comment.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        <div>
          {/* Author info */}
          <Card className="mb-6">
            <CardHeader>
              <h2 className="text-lg font-semibold">About the Creator</h2>
            </CardHeader>
            <CardContent>
              <div className="flex items-center mb-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={idea.user.avatar} alt={idea.user.name} />
                  <AvatarFallback>{idea.user.name?.charAt(0) || idea.user.username.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="ml-3">
                  <h3 className="font-medium">{idea.user.name}</h3>
                  <p className="text-sm text-neutral-light">{idea.user.college}</p>
                </div>
              </div>
              
              {idea.user.bio && (
                <p className="text-sm text-neutral-medium mb-4">{idea.user.bio}</p>
              )}
              
              <Button asChild variant="outline" className="w-full">
                <Link href={`/profile/${idea.user.id}`}>
                  View Profile
                </Link>
              </Button>
            </CardContent>
          </Card>
          
          {/* Team formation */}
          <Card>
            <CardHeader>
              <h2 className="text-lg font-semibold">Looking for Team Members</h2>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-neutral-medium mb-4">
                Interested in this idea? Join the team and help bring this vision to life!
              </p>
              
              <Button className="w-full">
                <i className="fas fa-user-plus mr-2"></i>
                Express Interest
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
};

export default IdeaDetails;
