import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { insertIdeaSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import PageHeader from "@/components/shared/PageHeader";

// Extend the schema with tags field
const formSchema = insertIdeaSchema.extend({
  tags: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema> & { tags: string };

const CreateIdea = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      problem: "",
      solution: "",
      targetAudience: "",
      tags: "",
    },
  });

  const createIdeaMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const { tags, ...ideaData } = values;
      
      // Process tags to convert comma-separated string to array
      const tagsArray = tags
        ? tags.split(",").map(tag => tag.trim()).filter(tag => tag.length > 0)
        : [];
      
      const response = await apiRequest("POST", "/api/ideas", { 
        ...ideaData,
        tags: tagsArray
      });
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Idea created",
        description: "Your idea has been posted successfully",
      });
      navigate("/ideas");
    },
    onError: (error: any) => {
      toast({
        title: "Error creating idea",
        description: error.message || "An error occurred while creating your idea",
        variant: "destructive",
      });
      setIsSubmitting(false);
    },
  });

  const onSubmit = (values: FormValues) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to post an idea",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    createIdeaMutation.mutate(values);
  };

  return (
    <>
      <PageHeader
        title="Post Your Idea"
        description="Share your startup vision with the community and find collaborators"
      />
      
      <div className="max-w-3xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Idea Details</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Idea Title</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Give your idea a catchy, descriptive title" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Brief Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Provide a concise overview of your idea (2-3 sentences)" 
                          className="min-h-[80px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="problem"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Problem Addressed</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="What problem does your idea solve?" 
                            className="min-h-[120px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="solution"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Your Solution</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="How does your idea solve this problem?" 
                            className="min-h-[120px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="targetAudience"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Audience</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Who will benefit from your solution?" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="tags"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tags</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Add tags separated by commas (e.g., MobileDev, EdTech, Healthcare)" 
                          {...field} 
                        />
                      </FormControl>
                      <FormDescription>
                        Tags help others find your idea more easily
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end">
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Posting..." : "Post Idea"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default CreateIdea;
