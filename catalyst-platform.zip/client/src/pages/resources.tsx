import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import PageHeader from "@/components/shared/PageHeader";
import { Resource, ResourceCategory } from "@shared/schema";
import { Search, ExternalLink, BookOpen, FileText, Scale, Code } from "lucide-react";

const Resources = () => {
  const [searchTerm, setSearchTerm] = useState("");
  
  const { data: categories = [] } = useQuery<ResourceCategory[]>({
    queryKey: ["/api/resources/categories"],
    queryFn: async () => {
      const res = await fetch("/api/resources/categories");
      return res.json();
    },
  });
  
  const { data: resources = [], isLoading } = useQuery<Resource[]>({
    queryKey: ["/api/resources"],
    queryFn: async () => {
      const res = await fetch("/api/resources");
      return res.json();
    },
  });
  
  // Filter resources based on search term
  const filteredResources = resources.filter(resource => {
    if (!searchTerm) return true;
    const searchLower = searchTerm.toLowerCase();
    return (
      resource.title.toLowerCase().includes(searchLower) ||
      (resource.description && resource.description.toLowerCase().includes(searchLower))
    );
  });
  
  // Group resources by category
  const resourcesByCategory = categories.reduce((acc, category) => {
    acc[category.id] = filteredResources.filter(
      resource => resource.categoryId === category.id
    );
    return acc;
  }, {} as Record<number, Resource[]>);
  
  const getCategoryIcon = (categoryName: string) => {
    const name = categoryName.toLowerCase();
    if (name.includes("learn")) return <BookOpen className="h-5 w-5" />;
    if (name.includes("business")) return <FileText className="h-5 w-5" />;
    if (name.includes("legal")) return <Scale className="h-5 w-5" />;
    if (name.includes("tech")) return <Code className="h-5 w-5" />;
    return <BookOpen className="h-5 w-5" />;
  };

  return (
    <>
      <PageHeader
        title="Resource Hub"
        description="Access curated learning materials, templates, and guides for your startup journey"
      />
      
      <div className="mb-6">
        <div className="relative max-w-md mx-auto">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search className="h-4 w-4 text-neutral-light" />
          </div>
          <Input
            type="search"
            placeholder="Search resources..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      {isLoading ? (
        <div className="text-center py-8">Loading resources...</div>
      ) : categories.length === 0 || resources.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-neutral-medium">No resources available yet.</p>
        </div>
      ) : (
        <Tabs defaultValue={categories[0]?.id.toString()}>
          <TabsList className="mb-6">
            {categories.map(category => (
              <TabsTrigger key={category.id} value={category.id.toString()}>
                {category.name}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {categories.map(category => (
            <TabsContent key={category.id} value={category.id.toString()}>
              {resourcesByCategory[category.id]?.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-neutral-medium">
                    {searchTerm 
                      ? `No resources found matching "${searchTerm}" in this category.` 
                      : `No resources available in ${category.name} yet.`}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {resourcesByCategory[category.id]?.map(resource => (
                    <ResourceCard 
                      key={resource.id} 
                      resource={resource} 
                      icon={getCategoryIcon(category.name)}
                    />
                  ))}
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      )}
    </>
  );
};

interface ResourceCardProps {
  resource: Resource;
  icon: React.ReactNode;
}

const ResourceCard = ({ resource, icon }: ResourceCardProps) => {
  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="rounded-full bg-primary/10 p-2 text-primary">
            {icon}
          </div>
          <CardTitle className="text-lg">{resource.title}</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col">
        {resource.description && (
          <CardDescription className="mb-4 flex-grow">
            {resource.description}
          </CardDescription>
        )}
        <Button asChild variant="outline" className="w-full mt-auto">
          <a href={resource.url} target="_blank" rel="noopener noreferrer">
            <ExternalLink className="h-4 w-4 mr-2" />
            Access Resource
          </a>
        </Button>
      </CardContent>
    </Card>
  );
};

export default Resources;
