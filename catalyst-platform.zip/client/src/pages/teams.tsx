import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import PageHeader from "@/components/shared/PageHeader";
import { useAuth } from "@/hooks/use-auth";
import { Team } from "@shared/schema";

const Teams = () => {
  const { user } = useAuth();
  
  const { data: teams = [], isLoading: isLoadingTeams } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
    queryFn: async () => {
      const res = await fetch("/api/teams");
      return res.json();
    },
    enabled: !!user,
  });
  
  const { data: userTeams = [], isLoading: isLoadingUserTeams } = useQuery<Team[]>({
    queryKey: ["/api/users", user?.id, "teams"],
    queryFn: async () => {
      const res = await fetch(`/api/teams?userId=${user?.id}`);
      return res.json();
    },
    enabled: !!user,
  });

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[80vh] text-center">
        <h1 className="text-2xl font-bold text-primary mb-4">Find Your Dream Team</h1>
        <p className="text-lg text-neutral-medium max-w-2xl mb-8">
          Please log in to browse and join teams or create your own.
        </p>
        <Button asChild size="lg">
          <Link href="/login">Log In</Link>
        </Button>
      </div>
    );
  }
  
  return (
    <>
      <PageHeader
        title="Find Teammates"
        description="Build your startup team with talented students from across colleges"
        action={
          <Button asChild>
            <Link href="/teams/create">
              <i className="fas fa-users mr-2"></i>
              Create a Team
            </Link>
          </Button>
        }
      />
      
      <Tabs defaultValue="all">
        <TabsList className="mb-6">
          <TabsTrigger value="all">All Teams</TabsTrigger>
          <TabsTrigger value="my-teams">My Teams</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          {isLoadingTeams ? (
            <div className="text-center py-8">Loading teams...</div>
          ) : teams.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-neutral-medium mb-4">No teams have been created yet.</p>
              <Button asChild>
                <Link href="/teams/create">Create the first team</Link>
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {teams.map((team) => (
                <TeamCard key={team.id} team={team} />
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="my-teams">
          {isLoadingUserTeams ? (
            <div className="text-center py-8">Loading your teams...</div>
          ) : userTeams.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-neutral-medium mb-4">You haven't joined any teams yet.</p>
              <div className="flex justify-center gap-4">
                <Button asChild>
                  <Link href="/teams/create">Create a Team</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link href="/ideas">Find Ideas</Link>
                </Button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {userTeams.map((team) => (
                <TeamCard key={team.id} team={team} isUserTeam />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </>
  );
};

interface TeamCardProps {
  team: Team & { 
    members?: { 
      userId: number; 
      role?: string; 
      user: { name: string; avatar?: string; username: string; } 
    }[]; 
    idea?: { title: string; } 
  };
  isUserTeam?: boolean;
}

const TeamCard = ({ team, isUserTeam }: TeamCardProps) => {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{team.name}</CardTitle>
          {isUserTeam && (
            <Badge variant="outline" className="bg-primary/10">
              Member
            </Badge>
          )}
        </div>
        {team.idea && (
          <div className="mt-1 text-sm text-neutral-medium">
            Working on: <span className="font-medium">{team.idea.title}</span>
          </div>
        )}
      </CardHeader>
      <CardContent>
        {team.description && (
          <p className="text-neutral-medium text-sm mb-4">{team.description}</p>
        )}
        
        {team.members && team.members.length > 0 && (
          <div className="mb-4">
            <h3 className="text-sm font-medium mb-2">Team Members:</h3>
            <div className="flex flex-wrap gap-2">
              {team.members.slice(0, 5).map((member) => (
                <Avatar key={member.userId} className="h-8 w-8">
                  <AvatarImage src={member.user.avatar} alt={member.user.name} />
                  <AvatarFallback>{member.user.name?.charAt(0) || member.user.username.charAt(0)}</AvatarFallback>
                  <span className="sr-only">{member.user.name}</span>
                </Avatar>
              ))}
              {team.members.length > 5 && (
                <div className="h-8 w-8 rounded-full bg-neutral-lightest flex items-center justify-center text-xs font-medium text-neutral-medium">
                  +{team.members.length - 5}
                </div>
              )}
            </div>
          </div>
        )}
        
        <Button asChild className="w-full">
          <Link href={`/teams/${team.id}`}>
            View Team
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
};

export default Teams;
