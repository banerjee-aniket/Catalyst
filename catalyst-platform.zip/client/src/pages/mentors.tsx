import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Mentor } from "@shared/schema";
import PageHeader from "@/components/shared/PageHeader";
import MentorCard from "@/components/mentors/MentorCard";
import { useState } from "react";
import { Search } from "lucide-react";

const expertiseAreas = [
  "All Areas",
  "Technology Entrepreneurship",
  "Product Management",
  "Marketing",
  "Finance",
  "Legal",
  "Design",
  "Engineering",
];

const Mentors = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [expertiseFilter, setExpertiseFilter] = useState("All Areas");
  
  const { data: mentors = [], isLoading } = useQuery<Mentor[]>({
    queryKey: ["/api/mentors"],
    queryFn: async () => {
      const res = await fetch("/api/mentors");
      return res.json();
    },
  });
  
  // Filter mentors based on search and expertise
  const filteredMentors = mentors.filter(mentor => {
    const matchesSearch = !searchTerm || 
      mentor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      mentor.expertise.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (mentor.bio && mentor.bio.toLowerCase().includes(searchTerm.toLowerCase()));
      
    const matchesExpertise = expertiseFilter === "All Areas" || 
      mentor.expertise.includes(expertiseFilter);
      
    return matchesSearch && matchesExpertise;
  });
  
  // Separate featured mentors
  const featuredMentors = filteredMentors.filter(mentor => mentor.featured);
  const regularMentors = filteredMentors.filter(mentor => !mentor.featured);

  return (
    <>
      <PageHeader
        title="Mentorship"
        description="Connect with industry experts and experienced entrepreneurs for guidance"
      />
      
      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search className="h-4 w-4 text-neutral-light" />
          </div>
          <Input
            type="search"
            placeholder="Search mentors by name or expertise..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <Select 
          defaultValue={expertiseFilter}
          onValueChange={setExpertiseFilter}
        >
          <SelectTrigger className="w-[180px] sm:w-[220px]">
            <SelectValue placeholder="Filter by expertise" />
          </SelectTrigger>
          <SelectContent>
            {expertiseAreas.map(area => (
              <SelectItem key={area} value={area}>
                {area}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {isLoading ? (
        <div className="text-center py-8">Loading mentors...</div>
      ) : filteredMentors.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-neutral-medium">
            {searchTerm || expertiseFilter !== "All Areas"
              ? "No mentors found matching your filters."
              : "No mentors available yet."}
          </p>
          {(searchTerm || expertiseFilter !== "All Areas") && (
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => {
                setSearchTerm("");
                setExpertiseFilter("All Areas");
              }}
            >
              Clear Filters
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-8">
          {featuredMentors.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold mb-4">Featured Mentors</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {featuredMentors.map(mentor => (
                  <MentorCard key={mentor.id} mentor={mentor} featured />
                ))}
              </div>
            </div>
          )}
          
          {regularMentors.length > 0 && (
            <div>
              {featuredMentors.length > 0 && (
                <h2 className="text-xl font-semibold mb-4">More Mentors</h2>
              )}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {regularMentors.map(mentor => (
                  <MentorCard key={mentor.id} mentor={mentor} />
                ))}
              </div>
            </div>
          )}
          
          <Card className="bg-primary/5 border-dashed">
            <CardHeader>
              <CardTitle>Looking for More Guidance?</CardTitle>
              <CardDescription>
                We're constantly expanding our mentor network to provide you with the best guidance.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full sm:w-auto">
                Request a Mentor in Your Field
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
};

export default Mentors;
