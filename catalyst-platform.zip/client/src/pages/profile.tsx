import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skill } from "@shared/schema";
import PageHeader from "@/components/shared/PageHeader";
import { apiRequest } from "@/lib/queryClient";
import SkillTag from "@/components/users/SkillTag";

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email address"),
  college: z.string().optional(),
  branch: z.string().optional(),
  year: z.string().optional(),
  bio: z.string().optional(),
  entrepreneurialStatus: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const Profile = () => {
  const { user, refreshUser } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedSkill, setSelectedSkill] = useState<number | null>(null);

  const { data: skills = [] } = useQuery<Skill[]>({
    queryKey: ["/api/skills"],
    queryFn: async () => {
      const res = await fetch("/api/skills");
      return res.json();
    },
  });

  const { data: userSkills = [] } = useQuery<Skill[]>({
    queryKey: ["/api/users", user?.id, "skills"],
    queryFn: async () => {
      const res = await fetch(`/api/users/${user?.id}`);
      const userData = await res.json();
      return userData.skills || [];
    },
    enabled: !!user,
  });

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: user?.name || "",
      email: user?.email || "",
      college: user?.college || "",
      branch: user?.branch || "",
      year: user?.year || "",
      bio: user?.bio || "",
      entrepreneurialStatus: user?.entrepreneurialStatus || "",
    },
  });

  useEffect(() => {
    if (user) {
      form.reset({
        name: user.name || "",
        email: user.email || "",
        college: user.college || "",
        branch: user.branch || "",
        year: user.year || "",
        bio: user.bio || "",
        entrepreneurialStatus: user.entrepreneurialStatus || "",
      });
    }
  }, [user, form]);

  const updateProfileMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const response = await apiRequest("PUT", `/api/users/${user?.id}`, values);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully",
      });
      refreshUser();
      setIsEditMode(false);
    },
    onError: (error: any) => {
      toast({
        title: "Update failed",
        description: error.message || "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const addSkillMutation = useMutation({
    mutationFn: async (skillId: number) => {
      const response = await apiRequest("POST", `/api/users/${user?.id}/skills/${skillId}`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", user?.id, "skills"] });
      setSelectedSkill(null);
    },
    onError: (error: any) => {
      toast({
        title: "Failed to add skill",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const removeSkillMutation = useMutation({
    mutationFn: async (skillId: number) => {
      const response = await apiRequest("DELETE", `/api/users/${user?.id}/skills/${skillId}`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", user?.id, "skills"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to remove skill",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: FormValues) => {
    updateProfileMutation.mutate(values);
  };

  const handleAddSkill = () => {
    if (selectedSkill) {
      addSkillMutation.mutate(selectedSkill);
    }
  };

  if (!user) {
    return <div>Please log in to view your profile.</div>;
  }

  const statusOptions = [
    { value: "looking_for_cofounder", label: "Looking for co-founder" },
    { value: "have_idea", label: "Have an idea" },
    { value: "looking_to_join", label: "Looking to join a team" },
    { value: "exploring", label: "Just exploring" },
  ];

  return (
    <>
      <PageHeader
        title="My Profile"
        description="Manage your profile information, skills, and projects"
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <Card>
            <CardHeader className="text-center">
              <Avatar className="mx-auto h-24 w-24 mb-4">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback className="text-2xl">{user.name?.charAt(0) || user.username.charAt(0)}</AvatarFallback>
              </Avatar>
              <CardTitle>{user.name || user.username}</CardTitle>
              <div className="text-sm text-neutral-medium mt-1">{user.college}</div>
              {user.entrepreneurialStatus && (
                <Badge className="mt-2 bg-primary">
                  {statusOptions.find(s => s.value === user.entrepreneurialStatus)?.label || user.entrepreneurialStatus}
                </Badge>
              )}
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">Username</h3>
                  <p className="text-neutral-medium">@{user.username}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium mb-2">Email</h3>
                  <p className="text-neutral-medium">{user.email}</p>
                </div>
                
                {user.branch && (
                  <div>
                    <h3 className="text-sm font-medium mb-2">Branch</h3>
                    <p className="text-neutral-medium">{user.branch}</p>
                  </div>
                )}
                
                {user.year && (
                  <div>
                    <h3 className="text-sm font-medium mb-2">Year of Study</h3>
                    <p className="text-neutral-medium">{user.year}</p>
                  </div>
                )}
                
                {user.bio && (
                  <div>
                    <h3 className="text-sm font-medium mb-2">About Me</h3>
                    <p className="text-neutral-medium">{user.bio}</p>
                  </div>
                )}
                
                <Button 
                  variant={isEditMode ? "outline" : "default"} 
                  className="w-full"
                  onClick={() => setIsEditMode(!isEditMode)}
                >
                  {isEditMode ? "Cancel Edit" : "Edit Profile"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="md:col-span-2">
          {isEditMode ? (
            <Card>
              <CardHeader>
                <CardTitle>Edit Profile</CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your full name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="Your email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="college"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>College</FormLabel>
                            <FormControl>
                              <Input placeholder="Your college name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="branch"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Branch</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. Computer Science" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="year"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Year of Study</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. 2nd Year" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="entrepreneurialStatus"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Entrepreneurial Status</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select your status" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {statusOptions.map(option => (
                                  <SelectItem key={option.value} value={option.value}>
                                    {option.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>About Me</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell others about yourself, your interests, and what you're passionate about" 
                              className="min-h-[120px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end">
                      <Button 
                        type="submit"
                        disabled={updateProfileMutation.isPending}
                      >
                        {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          ) : (
            <>
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Skills</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {userSkills.length === 0 ? (
                      <p className="text-neutral-medium">No skills added yet. Add some skills to showcase your expertise.</p>
                    ) : (
                      userSkills.map(skill => (
                        <SkillTag 
                          key={skill.id} 
                          skill={skill} 
                          onRemove={() => removeSkillMutation.mutate(skill.id)} 
                          removable 
                        />
                      ))
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <Select onValueChange={(value) => setSelectedSkill(Number(value))}>
                      <SelectTrigger className="w-[200px]">
                        <SelectValue placeholder="Add a skill" />
                      </SelectTrigger>
                      <SelectContent>
                        {skills
                          .filter(skill => !userSkills.some(us => us.id === skill.id))
                          .map(skill => (
                            <SelectItem key={skill.id} value={skill.id.toString()}>
                              {skill.name}
                            </SelectItem>
                          ))
                        }
                      </SelectContent>
                    </Select>
                    <Button 
                      onClick={handleAddSkill} 
                      disabled={!selectedSkill || addSkillMutation.isPending}
                    >
                      {addSkillMutation.isPending ? "Adding..." : "Add"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Projects & Portfolio</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <p className="text-neutral-medium mb-4">You haven't added any projects to your portfolio yet.</p>
                    <Button variant="outline">Add Project</Button>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default Profile;
