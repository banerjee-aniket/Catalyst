import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import IdeaCard from "@/components/ideas/IdeaCard";
import EventCard from "@/components/events/EventCard";
import MentorCard from "@/components/mentors/MentorCard";
import PageHeader from "@/components/shared/PageHeader";
import { useAuth } from "@/hooks/use-auth";
import { Idea, Event, Mentor } from "@shared/schema";

const Home = () => {
  const { user } = useAuth();
  
  const { data: featuredIdea } = useQuery<Idea & { user: any, tags: string[] }>({
    queryKey: ["/api/ideas", "featured"],
    queryFn: async () => {
      const res = await fetch("/api/ideas?featured=true&limit=1");
      const ideas = await res.json();
      return ideas[0];
    },
    enabled: !!user,
  });
  
  const { data: recentIdeas = [] } = useQuery<(Idea & { user: any })[]>({
    queryKey: ["/api/ideas", "recent"],
    queryFn: async () => {
      const res = await fetch("/api/ideas?limit=3");
      return res.json();
    },
    enabled: !!user,
  });
  
  const { data: events = [] } = useQuery<Event[]>({
    queryKey: ["/api/events"],
    queryFn: async () => {
      const res = await fetch("/api/events");
      return res.json();
    },
    enabled: !!user,
  });
  
  const { data: mentors = [] } = useQuery<Mentor[]>({
    queryKey: ["/api/mentors", "featured"],
    queryFn: async () => {
      const res = await fetch("/api/mentors?featured=true");
      return res.json();
    },
    enabled: !!user,
  });

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[80vh] text-center">
        <h1 className="text-4xl font-bold text-primary mb-4">Welcome to Catalyst</h1>
        <p className="text-xl text-neutral-medium max-w-2xl mb-8">
          Empowering Tier 3 college students to connect, collaborate, and create successful startups together.
        </p>
        <div className="flex gap-4">
          <Button asChild size="lg">
            <Link href="/register">Get Started</Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link href="/login">Login</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <PageHeader
        title="Discover & Collaborate"
        description="Connect with like-minded entrepreneurs, find ideas, and build your dream team"
      />
      
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Main feed column - Idea Marketplace */}
        <div className="lg:col-span-2 space-y-6">
          {/* Featured idea */}
          {featuredIdea && (
            <IdeaCard 
              idea={featuredIdea} 
              featured 
              showActions
            />
          )}
          
          {/* Recent ideas section */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Recent Ideas</h2>
              <Link href="/ideas" className="text-sm font-medium text-primary hover:text-primary-dark">View all</Link>
            </div>
            
            {recentIdeas.map(idea => (
              <IdeaCard 
                key={idea.id} 
                idea={idea}
                className="mb-4 last:mb-0"
                showActions
              />
            ))}
          </div>
        </div>
        
        {/* Right sidebar content */}
        <div className="space-y-6">
          {/* Call to action card */}
          <div className="bg-gradient-to-r from-primary to-primary-dark text-white rounded-lg shadow p-5">
            <h2 className="text-lg font-semibold">Have a Startup Idea?</h2>
            <p className="mt-2 text-sm text-white text-opacity-90">Share your vision, get feedback, and find team members to build it together.</p>
            <Button asChild className="mt-4 w-full bg-white text-primary hover:bg-gray-50">
              <Link href="/ideas/create">
                <i className="fas fa-plus mr-2"></i>
                Post Your Idea
              </Link>
            </Button>
          </div>
          
          {/* Trending skills */}
          <div className="bg-white shadow rounded-lg p-5">
            <h2 className="text-lg font-semibold mb-4">Trending Skills</h2>
            <ul className="space-y-3">
              <li className="flex justify-between items-center">
                <span className="text-sm font-medium">AI/Machine Learning</span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                  <i className="fas fa-arrow-up text-xs mr-1"></i> 32%
                </span>
              </li>
              <li className="flex justify-between items-center">
                <span className="text-sm font-medium">UI/UX Design</span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                  <i className="fas fa-arrow-up text-xs mr-1"></i> 28%
                </span>
              </li>
              <li className="flex justify-between items-center">
                <span className="text-sm font-medium">Blockchain</span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                  <i className="fas fa-arrow-up text-xs mr-1"></i> 25%
                </span>
              </li>
              <li className="flex justify-between items-center">
                <span className="text-sm font-medium">Digital Marketing</span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  <i className="fas fa-arrow-up text-xs mr-1"></i> 20%
                </span>
              </li>
              <li className="flex justify-between items-center">
                <span className="text-sm font-medium">Mobile Development</span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  <i className="fas fa-arrow-up text-xs mr-1"></i> 18%
                </span>
              </li>
            </ul>
            <Link href="/profile" className="mt-4 block text-center text-sm font-medium text-primary hover:text-primary-dark">
              Update your skills
            </Link>
          </div>
          
          {/* Upcoming events */}
          <div className="bg-white shadow rounded-lg p-5">
            <h2 className="text-lg font-semibold mb-4">Upcoming Events</h2>
            <div className="space-y-4">
              {events.slice(0, 3).map(event => (
                <EventCard key={event.id} event={event} />
              ))}
            </div>
            <Link href="/events" className="mt-4 block text-center text-sm font-medium text-primary hover:text-primary-dark">
              View all events
            </Link>
          </div>
          
          {/* Featured mentors */}
          <div className="bg-white shadow rounded-lg p-5">
            <h2 className="text-lg font-semibold mb-4">Featured Mentors</h2>
            <div className="space-y-4">
              {mentors.slice(0, 2).map(mentor => (
                <MentorCard key={mentor.id} mentor={mentor} />
              ))}
            </div>
            <Link href="/mentors" className="mt-4 block text-center text-sm font-medium text-primary hover:text-primary-dark">
              Find a mentor
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
